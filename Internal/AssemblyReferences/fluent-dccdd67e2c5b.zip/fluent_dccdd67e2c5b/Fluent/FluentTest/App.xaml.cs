using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Threading;
using System.Windows;
using Fluent;

namespace FluentTest
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        static App()
        { 
   //Ribbon.ResetState();

            //Thread.CurrentThread.CurrentUICulture = new CultureInfo("fa");
            //Thread.CurrentThread.CurrentUICulture = new CultureInfo("ru");
            //Thread.CurrentThread.CurrentUICulture = new CultureInfo("de");
            //Thread.CurrentThread.CurrentUICulture = new CultureInfo("hu");
            //Thread.CurrentThread.CurrentUICulture = new CultureInfo("cs");
            //Thread.CurrentThread.CurrentUICulture = new CultureInfo("fr");
            //Thread.CurrentThread.CurrentUICulture = new CultureInfo("pl");
            //Thread.CurrentThread.CurrentUICulture = new CultureInfo("ja");
            //Thread.CurrentThread.CurrentUICulture = new CultureInfo("nl");
            //Thread.CurrentThread.CurrentUICulture = new CultureInfo("pt-PT");
            //Thread.CurrentThread.CurrentUICulture = new CultureInfo("pt-br");
            //Thread.CurrentThread.CurrentUICulture = new CultureInfo("es");
            //Thread.CurrentThread.CurrentUICulture = new CultureInfo("zh");
            //Thread.CurrentThread.CurrentUICulture = new CultureInfo("sv");
            //Thread.CurrentThread.CurrentUICulture = new CultureInfo("sk");
            //Thread.CurrentThread.CurrentUICulture = new CultureInfo("uk");
            //Thread.CurrentThread.CurrentUICulture = new CultureInfo("ro");
            //Thread.CurrentThread.CurrentUICulture = new CultureInfo("it");
            //Thread.CurrentThread.CurrentUICulture = new CultureInfo("ar");
            //Thread.CurrentThread.CurrentUICulture = new CultureInfo("da");
            //Thread.CurrentThread.CurrentUICulture = new CultureInfo("az");
        }

        public App()
        {
            //System.Threading.Thread.CurrentThread.CurrentUICulture = new System.Globalization.CultureInfo("ru-RU"); ;
        }

        private void OnApplicationStartup(object sender, StartupEventArgs e)
        {
            
        }
    }
}
